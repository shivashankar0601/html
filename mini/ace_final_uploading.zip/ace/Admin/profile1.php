<?php

	$no = $_SESSION['rollno'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from profile where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
	
	$row=mysqli_fetch_array($db);	

	$set=0;


	echo "
			
			
			</br></br><font color='#FFFFFF' size='4' background-color='#000000'  >
			<table border='1' width='90%' colspan='5' align='center' width='50%' > ";

	do
	{
		
		echo "		
		<tr><th><center> Student Roll No</center></th>      <td width='70%' ><center>$row[0]</center></td></tr>
		<tr><th><center> Student Name  </center></th>      <td width='70%' ><center>$row[1]</center></td></tr>
		<tr><th><center> Student Contact no  </center></th>      <td width='70%' ><center>$row[2]</center></td></tr>
		<tr><th><center> Father Name  </center></th>      <td width='70%' ><center>$row[3]</center></td></tr>
		<tr><th><center> Father Contact no  </center></th>      <td width='70%' ><center>$row[4]</center></td></tr>
		<tr><th><center> Student Date Of Birth  </center></th>      <td width='70%' ><center>$row[5]</center></td></tr>
		<tr><th><center> Batch  </center></th>      <td width='70%' ><center>$row[6]</center></td></tr>
		<tr><th><center> Branch  </center></th>      <td width='70%' ><center>$row[7]</center></td></tr>
		";
		
		$set=$row[10];	
		
		
		
		
		$db =mysqli_query($conn,"select sum(backlog) from aggregate where rollno='$no' ;") or die ( " <br> backlogs problem");
		$row=mysqli_fetch_array($db);
		
		
		echo "<tr><th><center> Backlogs  </center></th>      <td width='70%' ><center>$row[0]</center></td></tr>";
		
		$db =mysqli_query($conn,"select (sum(total)/sum(off))*100 from aggregate where rollno='$no' ;") or die ( " <br> database useage not availabe ");
		$row=mysqli_fetch_array($db);
		
		
		echo"<tr><th><center> Current Aggregate  </center></th>      <td width='70%' ><center>$row[0]</center></td></tr>
		</table>";
		
		
	}while($row=mysqli_fetch_array($db));
	
	?>
