<?php

	session_start();
?>

<?php

		
	if( isset($_POST["un"]) && isset($_POST["pw"]) )
	{
		
		
		$a=$_POST["un"];
		
		$b=$_POST["pw"];
				
		$dbhost = 'localhost';

		$dbuser = 'root';

		$dbpass = 'root';

		$dbname = 'ace';
		
		echo " <body > <br><br><br><br><br><br><br><br><br><center> Please Wait , Your Credentials are being VALIDATED</center>";
		
	
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

		$db =mysqli_query($conn,"select * from admin;") or die ( " <br> database useage not availabe you know ");
	
		while($row=mysqli_fetch_array($db))
	
		{
		
			if($row[0]==$a && $row[1]==$b)
			{
				
				$_SESSION['name']=$row[2];
				
				header( "Location: home.php" ) or die(" page couldn't be called ");		
				
			}
			
		}
		header( "Location: index.html" ) or die(" page couldn't be called ");
		
	}
	else
	{
		echo " wrong information " ;
	}
?>

