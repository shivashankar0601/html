<?php
	
	session_start();
	
	
	$sem = $_POST['sem'];
		
	$file = fopen("marks.csv","r");

	$array[]=array(fgetcsv($file));

	$t=0;

	$data=array();

	$i=0;

	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
		
	echo " <body bgcolor='lavander'> ";
		
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");
echo "<body bgcolor='lavander' ><br><br><br><br><br><br><br><br><br><br><br><br><br><h1><center>";

$inc=1;

$total=0;

$b=0;

$rno="";

while(!feof($file))


{

	$array[]=array(fgetcsv($file));

	$c = array_values($array[$i++]);


	$data[$t++]=$c[0][0];
	
	if($inc==1)
		$rno=$c[0][0];

	$data[$t++]=$c[0][1];
	

	$data[$t++]=$c[0][2];
	
	

	$data[$t++]=$c[0][3];
	

	$data[$t++]=$c[0][4];
	

	$data[$t++]=$c[0][5];
	
	$total=$total+$data[$t-1];
	
	
	
	$data[$t++]=$c[0][6];
	if($data[$t-1]==0)
	{
		$b=$b+1;
	}
	

	mysqli_query($conn,"insert into marks values ( '$data[0]','$data[1]','$data[2]',$data[3],$data[4],$data[5],$data[6],'$sem',$inc); ") or die ( " <br> problem inserting in to marks database ");
	$t=0;
	$inc++;
	
	if($inc==9 )
	{

		if($rno==$c[0][0])
		{
			$inc=1;
			$out=750;
		
			mysqli_query($conn,"insert into aggregate values ('$data[0]','$sem',$b,$total,$out);") or die ( " <br> problem inserting in to aggregate database ");
			$total=0;
			$b=0;	
		}
		else
		{

			$inc=1;
		
			$total=0;
			$b=0;
		}

	}

}

$_SESSION['kept']=1;

	echo " <script> confirm('Data Uploaded Successfully');</script> </h1> ";
	
	header( "Location: uploadindex.php" ) or die(" page couldn't be called ");
	
	
	

	mysqli_close($conn);
	


fclose($file);
?> 



