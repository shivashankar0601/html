<?php

	$no = $_SESSION['rollno'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from complaints where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
	
	$row=mysqli_fetch_array($db);	


	echo "</br></br><font color='#FFFFFF' size='4' background-color='#000000'  >
		<table border='1' width='90%' colspan='5' align='center' width='50%' >	
			<tr><th><center> Student Roll No</center></th>><th><center> Message</center></th><th><center>Image</center></th></tr>";
	
	
	do
	{
		
		echo "<tr><td><center>$row[0]</td><td><center>$row[1]</td><td><center><a href='../complaints/$row[2]' target='_blank' ><img src='../complaints/$row[2]' width='200' height='150' id='age'      /></a></td></tr>";
		
		
	}while($row=mysqli_fetch_array($db));
	
	?>
