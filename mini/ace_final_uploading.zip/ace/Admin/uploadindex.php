<?php
	session_start();
	
	
	if($_SESSION['kept']==1)
		echo '<script>alert(" Data uploaded Sucessfully ");</script>';
	
	
		
?>


<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>ACE Student Profile</title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="../assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>





    <!-- Navigation -->
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">HOME</a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                	
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
          </header>
    <!--End Navigation -->

    

    <!-- Navigation -->
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Current User :
                 <?php                
                	$name=$_SESSION['name'];
                	echo $name ;
                ?>
                
                
                
                </a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                
                    <li><a href="home.php">Dashboard</a></li>
                    <li><a href="logout.php">Log-out</a></li>
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
          </header>
    <!--End Navigation -->

    

  
    <!--Header section  -->
    <div id="home">
    <div class="container" >
        
        
        
        
        
        
               
               
               <!-- DATA FROM HERE -->
               
               
               
                <script type='text/javascript'>
				location.hash='#no-';
				if(location.hash == '#no-')
				{
					location.hash='#_';
					window.onhashchange=function()
					{
						if(location.hash == '#no-')
							location.hash='#_';
					}
				}
			</script>
                   
                   
                   
                  <div class="col-md-33 col-ss-3">
                   
                   </br></br></br></br></br><font color="#ffffff" size="20px" ><center>Upload Marks Into Database</center></font>                   
                   <div class="div-transs text-center"> 
                   
                   
                   

                   
                   
           
               
               
                </br></br></br></br></br></br></br>
                
                <form action='upload.php' method='post'>
	 		<center>Select Semister / year <select name="sem" >
				<option value="1">1st year</option>
				<option value="2">2-1 semister</option>
				<option value="3">2-2 semister</option>
				<option value="4">3-1 semister</option>
				<option value="5">3-2 semister</option>
				<option value="6">4-1 semister</option>
				<option value="7">4-2 semister</option>
			</select> 
	
			<input type='submit' value='submit' /></center>
	
		</form>
                
                
                	
                
                   </font>
 
 </div> 
 </div>
 </div>
       
                 
                 <!-- DATA TILL HERE -->  
                
         
      
          </div>
    <!--End Header section  -->
    <!--Services Section-->
    
    

    <!-- Contact Section -->
    <section  id="contact-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                
                    <div id="social-icon">
                          <strong>  Address : </strong>ACE engineering college , Ankushapur , Ghatkesar , 501301 , Hyderabad .
                        <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                        <a href="#"><i class="fa fa-twitter fa-2x"></i></a>
                        <a href="#"><i class="fa fa-linkedin fa-2x"></i></a>
                        <a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
                        <a href="#"><i class="fa fa-pinterest fa-2x"></i></a>
                    </div>
                </div>
                

            </div>
        </div>
    </section>

    <!--End Contact Section -->
    <!--footer Section -->
    <div class="for-full-back " id="footer">
        2017 www.aceec.ac.in | All Right Reserved
         
    </div>
    <!--End footer Section -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="../assets/plugins/bootstrap.js"></script>
    <!-- PARALLAX SCRIPT   -->
    <script src="../assets/plugins/4jquery.parallax-1.1.3.js"></script>
    <!-- CUSTOM SCRIPT   -->
    <script src="../assets/js/custom.js"></script>
</body>
</html>









































		
