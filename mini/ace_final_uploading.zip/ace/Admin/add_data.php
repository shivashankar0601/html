<?php

$a=$_POST['rollno'];
$b=$_POST['sname'];
$c=$_POST['sno'];
$d=$_POST['fname'];
$e=$_POST['fno'];
$f=$_POST['bday'];
$g=$_POST['bat'];
$h=$_POST['branch'];
$i=0;
$j=0;



	



	if( isset($a) && isset($b) && isset($c) && isset($d) && isset($e) && isset($f) && isset($g) && isset($h) && isset($i) && isset($j) )
	
	{

		$dbhost = 'localhost';
	
		$dbuser = 'root';
	
		$dbpass = 'root';
	
		$dbname = 'ace';
		
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");
	
		$db =mysqli_query($conn,"insert into profile values ('$a','$b','$c','$d','$e','$f','$g','$h',$i,$j,0); ") or die ( " <br> PROFILE TABLE is not available ");
		
		echo "<script> alert(' Data uploaded successfully')</script>";
		
		header( "Location: home.php" ) or die(" page couldn't be called ");	
		
		
		
	
	}
	else
	{
		echo "<script> alert(' DATA Provided is insufficient')</script>";
		header( "Location: add.php" ) or die(" page couldn't be called ");
	}
				
			
			

?>
