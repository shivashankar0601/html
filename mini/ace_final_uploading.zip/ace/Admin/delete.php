            
<?php
	session_start();
?>


<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Student Results</title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="../assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>





    <!-- Navigation -->
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Administrator :
                 <?php                
                	$name=$_SESSION['name'];
                	if($name==null)
                		echo $name;
                	else
                		echo $name ;
                ?>
                
                
                
                </a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                <li><a href="home.php"><font size=4>Dashboard</font></a></li>
                	 <li><a href="logout.php"><font size=4>Log-out</font></a></li>
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
          </header>
    <!--End Navigation -->

    

  
    <!--Header section  -->
    <div id="home">
    <div class="container" >
        
        
        
        
        
        
               
               
               <!-- DATA FROM HERE -->
               
               
               
                <script type='text/javascript'>
				location.hash='#no-';
				if(location.hash == '#no-')
				{
					location.hash='#_';
					window.onhashchange=function()
					{
						if(location.hash == '#no-')
							location.hash='#_';
					}
				}
				
				
				
			</script>

                   
                   
                  <div class="col-md-33 col-ss-3">
                   
                   
                  </br></br></br></br><font color="#ffffff" size="20px" ><center><b>Student Deletion Form</b></center></font>
                   
                   <div class="div-transs text-center"> 
                   
                   
                  
<br><br><br><font color='#ffffff' >

		


		<center><h3><form action='delete.php' method='post'>
		<table width="60%">
		<tr><td><center>Rollno  </td><td><center><input type="text" name="rollno" placeholder="Ex : 13AG1A0XXX" /></center></td></tr>
		
</table></br>
				<input type='submit' value="submit Data" onclick="return confirm('Are you sure to delete the data ?');" />
	
		 
		 </form>
		 
<?php

	if(isset($_POST['rollno']))
	{
		$a=$_POST['rollno'];
		
		$dbhost = 'localhost';
	
		$dbuser = 'root';
	
		$dbpass = 'root';
	
		$dbname = 'ace';
		
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");
	
		$db =mysqli_query($conn,"delete from profile where rollno='$a' ;");
		
		$db =mysqli_query($conn,"delete from aggregate where rollno='$a' ;");

		$db =mysqli_query($conn,"delete from marks where rollno='$a' ;");
				
		$db =mysqli_query($conn,"delete from authentication where rollno='$a' ;");
		
		echo "<script> alert(' DATA Deleted successfully ')</script>";
		
	}
	
?>
		
		
