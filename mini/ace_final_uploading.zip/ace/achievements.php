<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Student Achievements</title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <!-- Navigation -->
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Curious Bird</a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="home.php">Profile</a></li>
                                        
                   
                    <li><a href="result.php">Results</a>
                    </li>
                    <li><a href="#">Achievements</a>
                    </li>
                    <li><a href="complaints.php">Complaints</a>
                    </li>
                    <li><a href="logout.php">Log-out</a>
                    </li>
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
          </header>
    <!--End Navigation -->

    

  
    <!--Header section  -->
    <div id="home">
    
    
    	<div class="col-md-33 col-sm-3">
                   <div class="div-trans text-center">
                       

<?php

	session_start();
?>


<?php

	$name = $_SESSION['uname'];
	$no = $_SESSION['rno'];

	$type=$_POST['atype'];
	
	$mes=$_POST['message'];

	if(isset($_FILES['image']) && isset($type) && isset($mes) )
	
	{
		$errors= array();
		$file_name = $_FILES['image']['name'];
      		$file_size =$_FILES['image']['size'];
      		$file_tmp =$_FILES['image']['tmp_name'];
    		  $file_type=$_FILES['image']['type'];
    		  $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
   		   $expensions= array("jpeg","jpg","png");
      
  		    if(in_array($file_ext,$expensions)=== false){
		         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
 		     }
      
  		    if($file_size > 2097152){
   		      $errors[]='File size must be excately 2 MB';
   		   }
      
   		   if(empty($errors)==true)
   		   {
    		     move_uploaded_file($file_tmp,"achievements/".$file_name);
    		     
    		     $dbhost = 'localhost';

			$dbuser = 'root';

			$dbpass = 'root';

			$dbname = 'ace';
		
			$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

			$db =mysqli_query($conn,"insert into achievements values ('$no','$type','$mes','$file_name');") or die ( " <br> database useage not availabe you know ");
    		     
    		     
    		     
  		       echo "<script> alert(' Achievement uploaded successfully')</script>";
  		    }else{
  		       echo "<script> alert(' $errors')</script>";
 		}
 		
 		
 			
    		     
 		
 		
 		
 		
 		
 		
 				
	}


?>


                                            
                        <form action="" method="POST" enctype="multipart/form-data">
                       
                       <h3>Submit your Achievements with Documented Proof</h3>
                       
                       
      <center><select name='atype' width:100px required="required" >
				<option value='0'>Select Curricular Type</option>
				<option value='Curricular'>Curricular</option>
				<option value='Co-Curricular'>Co-Curricular</option>
				<option value='Extra-Curricular'>Extra Curricular</option>
			</select>
			
			</br></br>     
                        
                            <div class="col-md-12 col-sm-12">
                                <div class="form-group">
                                    <textarea name="message" id="Textarea1" required="required" class="form-control" rows="6" placeholder="Please Enter Your Message ( Maxlength 200 characters )" maxlength="200"></textarea>
         
 
	 		
			
	
	 </br>(Accepted Formats like .jpeg/.jpg/.png) <input type="file" name="image" id="file" required="required" />
	 
	  </br></br>		<input type='submit' value="submit Data" /></center>
	
			</form>
                   </div>
   
            </div>

    
    
    
    
    
    
    
          
               
     </div>
    <!--End Header section  -->
    <!--Services Section-->
    
    

    <!-- Contact Section -->
    <section  id="contact-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                
                    <div id="social-icon">
                          <strong>  Address : </strong>ACE engineering college , Ankushapur , Ghatkesar , 501301 , Hyderabad .
                        <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                        <a href="#"><i class="fa fa-twitter fa-2x"></i></a>
                        <a href="#"><i class="fa fa-linkedin fa-2x"></i></a>
                        <a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
                        <a href="#"><i class="fa fa-pinterest fa-2x"></i></a>
                    </div>
                </div>
                

            </div>
        </div>
    </section>

    <!--End Contact Section -->
    <!--footer Section -->
    <div class="for-full-back " id="footer">
        2017 www.aceec.ac.in | All Right Reserved
         
    </div>
    <!--End footer Section -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.js"></script>
    <!-- PARALLAX SCRIPT   -->
    <script src="assets/plugins/4jquery.parallax-1.1.3.js"></script>
    <!-- CUSTOM SCRIPT   -->
    <script src="assets/js/custom.js"></script>
</body>
</html>





































