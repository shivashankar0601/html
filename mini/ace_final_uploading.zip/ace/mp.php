
 <?php



	$name =$_REQUEST['name'];
	$no = $_REQUEST['no'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from profile where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
	
	if($row=mysqli_fetch_array($db))
	{	

		$set=0;
		
		echo "$row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7],";
		
		$set=$row[10];
		
		$db =mysqli_query($conn,"select sum(backlog) from aggregate where rollno='$no' ;") or die ( " <br> backlogs problem");
		$row=mysqli_fetch_array($db);
		
		
		echo "$row[0],";
		
		$db =mysqli_query($conn,"select (sum(total)/sum(off))*100 from aggregate where rollno='$no' ;") or die ( " <br> database useage not availabe ");
		$row=mysqli_fetch_array($db);
		
		
		echo"$row[0],";
	}
	else
	{
		echo"-1";
	}
		
?>
