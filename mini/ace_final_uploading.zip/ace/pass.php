<html>
	<body background="assets/img/head.jpg" height="350" width="350">
	
	<?php
	
		session_start();
	?>
	
	<?php
	
		$no = $_SESSION['rno'];
	
		$c = $_POST['c'];
		
		$f=  $_POST['n1'];
	
		$s =  $_POST['n2'];
	
		if($f==$s && isset($c) && isset($f) && isset($s) ){
	
		$dbhost = 'localhost';

		$dbuser = 'root';

		$dbpass = 'root';

		$dbname = 'ace';
	
		$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

		$db =mysqli_query($conn,"select pswd from authentication where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
	
		$row=mysqli_fetch_array($db);	
	
		if($row[0]==$c)
		{
			mysqli_query($conn,"update authentication set pswd = '$f' where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
			echo "<script>alert('Password Changed Successfully'); window.open('home.php','_self');</script>";
				
		}
		else
			
			echo "<script>alert('wrong information , try again');</script>";
	
	
	
	}
	
	
	?>
	
	
	
	
	
	<br><br><br><br><br><br><br><cener>
	
		<h2> <center>Change Your Current Password </h2>
	<br><br>
		<form action="" method="post" >
		
		
<center>		Current Password :- <input type="password" name="c" />
			
			<br><br>
			
<center>		New Password :- <input type="password" name="n1"/> 
	
			<br><br>
			
<center>		Re-Enter Password :- <input type="password" name="n2"/>
			<br><br>
			<center><pre><input type="submit" value="submit" />          <input type="button" value="cancel" onclick="window.close()" /></pre></center>
	

	</body>
	
</html>
