             
<?php
	session_start();
?>


<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Student Results</title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body>





    <!-- Navigation -->
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Curious Bird</a>
            </div>
            <!-- Collect the nav links for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                	<li><a href="home.php">Profile</a></li>
                
                    
                    <li><a href="#">Results</a>
                    </li>
                    <li><a href="achievements.php">Achievements</a>
                    </li>
                    <li><a href="complaints.php">Complaints</a>
                    </li>
                    <li><a href="logout.php">Log-out</a>
                    </li>
                    
                   
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
          </header>
    <!--End Navigation -->

    

  
    <!--Header section  -->
    <div id="home">
    <div class="container" >
        
        
        
        
        
        
               
               
               <!-- DATA FROM HERE -->
               
               
               
                <script type='text/javascript'>
				location.hash='#no-';
				if(location.hash == '#no-')
				{
					location.hash='#_';
					window.onhashchange=function()
					{
						if(location.hash == '#no-')
							location.hash='#_';
					}
				}
			</script>
                   
                   
                   
                  <div class="col-md-33 col-ss-3">
                   
                   </br></br></br></br><font color="#ffffff" size="20px" ><center><b>Results</b></center></font>
                   
                   <div class="div-transs text-center"> 
                   
                   
                  
<br><br><br><br><font color='#ffffff' ><center><h3><form action='result.php' method='post'>
	 			<center>Select Semister / year to see the results :- <select name='get' >
					<option value="-1">Select</option>
					<option value="1">1st year</option>
					<option value="2">2-1 semister</option>
					<option value="3">2-2 semister</option>
					<option value="4">3-1 semister</option>
					<option value="5">3-2 semister</option>
					<option value="6">4-1 semister</option>
					<option value="7">4-2 semister</option>
				</select> 
	
				<input type='submit' value='submit' /></center>
	
			</form>
						               

<?php

	$name = $_SESSION['uname'];
	$no = $_SESSION['rno'];
	$s=$_POST['get'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' ") or die ( " <br> MARKS TABLE is not available ");
		
		
	if($row=mysqli_fetch_array($db))
	
	{
		
		
	$db =mysqli_query($conn,"select sum(tot) from marks where rollno ='$no' AND sem='$s' ;") or die ( " <br> Problem with Marks table ");
		
		$row=mysqli_fetch_array($db);
		
		
		print("</br></br><table border='1' align='center' width='100%' >");
			
		print("<tr><th><center>Marks Obtained</center></th><td><center>$row[0]</center></td>");
	
		if($s==1)
			$total=1000;
		else
			$total=750;
	
		print("<th><center>Out Of Marks</th></center><td><center>$total</center></td></tr>");
	
		print("<tr><th><center>Percentage</center></th><td><center>".(($row[0]/$total)*100)."");
	
	
		$db =mysqli_query($conn,"select count(cre) from marks where rollno='$no' and cre=0;") or die ( " <br> Problem with Marks table ");
			
		$row=mysqli_fetch_array($db);
	
		print("</center></td><th><center>Backlogs</th></center><td><center>$row[0]</center></td></tr></table>");
		
		
		
		
		
		
		$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=1;") or die ( " <br> MARKS TABLE is not available ");
		
		$row=mysqli_fetch_array($db);
		
		
		print("<h4><center><table border='1' align='center' width='90%' >		
				<th><center>Subjects</center></th><th><center>Internals</center></th><th><center>Externals</center></th><th><center>Total</center></th><th><center>Credits</center></th>
				<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=2  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				
		print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=3 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				
		print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
			
			
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=4  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
			
			
				print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
			
			
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=5 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
			
				print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=6 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
				
				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=7 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>");
				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=8  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				print("<tr><th><center>$row[2]</center></th><td><center>$row[3]</td></center><td><center>$row[4]</td></center><td><center>$row[5]</td></center><td><center>$row[6]</td></center></tr>
			</table></h4></center>");	
			
	
	}
	else
	{
		echo "</br></br><h3><center>RESULTS WILL BE SHOWN HERE</center></h3> ";
	}
				
			
			
		
?>
                  
                  
                  
                   
 

 
 
 
 </div>
 
 
 
 </div>
 </div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                   
                   
             
                   
                   
                   
                 <!-- DATA TILL HERE -->  
                
         
      
          </div>
    <!--End Header section  -->
    <!--Services Section-->
    
    

    <!-- Contact Section -->
    <section  id="contact-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                
                    <div id="social-icon">
                          <strong>  Address : </strong>ACE engineering college , Ankushapur , Ghatkesar , 501301 , Hyderabad .
                        <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                        <a href="#"><i class="fa fa-twitter fa-2x"></i></a>
                        <a href="#"><i class="fa fa-linkedin fa-2x"></i></a>
                        <a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
                        <a href="#"><i class="fa fa-pinterest fa-2x"></i></a>
                    </div>
                </div>
                

            </div>
        </div>
    </section>

    <!--End Contact Section -->
    <!--footer Section -->
    <div class="for-full-back " id="footer">
        2017 www.aceec.ac.in | All Right Reserved
         
    </div>
    <!--End footer Section -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.js"></script>
    <!-- PARALLAX SCRIPT   -->
    <script src="assets/plugins/4jquery.parallax-1.1.3.js"></script>
    <!-- CUSTOM SCRIPT   -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
