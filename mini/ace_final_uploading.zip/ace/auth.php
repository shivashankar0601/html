<?php

$a=$_REQUEST['name'];
$b=$_REQUEST['pass'];


if(isset($_REQUEST['name'])  && isset($_REQUEST['pass']) )
{

	$db=mysqli_connect('localhost','root','root','ace') or die ("something wrong with Database");
	$data=mysqli_query($db," select count(*) from authentication where uname= '$a' and pswd='$b';") or die (" Something Wrong with Table insertion ");
	if($row=mysqli_fetch_array($data))
	{
		
		echo "$row[0]";
		return;
	}
	echo "0";
}

else
{
	echo "nothing 1";
	
}

?>
