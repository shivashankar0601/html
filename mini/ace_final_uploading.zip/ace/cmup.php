<?php
  
 if($_SERVER['REQUEST_METHOD']=='POST'){
 
 $image = $_POST['image'];
 $name = $_POST['name'];
 $data = $_POST['data'];
 
 $rno = $_POST['rno'];
 
 
 
 
 $path = "complaints/".$name.".jpg";

 if(true){
 file_put_contents($path,base64_decode($image));
 
 $dbhost = 'localhost';

$dbuser = 'root';

$dbpass = 'root';

$dbname = 'ace';
		
$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) ;

$db =mysqli_query($conn,"insert into complaints values ('$rno','$data','$name');");
 
 
 echo "Successfully Uploaded";
 }
 
 }else{
 echo "Error";
 }
