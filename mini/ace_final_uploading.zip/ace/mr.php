<?php

	$name = $_REQUEST['uname'];
	$no = $_REQUEST['rno'];
	$s=$_REQUEST['sem'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' ") or die ( " <br> MARKS TABLE is not available ");
		
		
	if($row=mysqli_fetch_array($db))
	
	{
		
		
	$db =mysqli_query($conn,"select sum(tot) from marks where rollno ='$no' AND sem='$s' ;") or die ( " <br> Problem with Marks table ");
		
		$row=mysqli_fetch_array($db);
		
		echo" $row[0]";
	
		if($s==1)
			$total=1000;
		else
			$total=750;
	
		echo ",$total,";
	
		echo (($row[0]/$total)*100) ;
	
	
		$db =mysqli_query($conn,"select count(cre) from marks where rollno='$no' and cre=0;") or die ( " <br> Problem with Marks table ");
			
		$row=mysqli_fetch_array($db);
	
		echo ",$row[0],";
		
		
		
		
		
		
		$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=1;") or die ( " <br> MARKS TABLE is not available ");
		
		$row=mysqli_fetch_array($db);
		
		
		echo "$row[2],$row[3],$row[4],$row[5],";
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=2  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				
				echo "$row[2],$row[3],$row[4],$row[5],";

				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=3 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
				
				echo "$row[2],$row[3],$row[4],$row[5],";

			
			
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=4  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
			
			
						echo "$row[2],$row[3],$row[4],$row[5],";

			
			
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=5 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
			
						echo "$row[2],$row[3],$row[4],$row[5],";

				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=6 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
						echo "$row[2],$row[3],$row[4],$row[5],";

				
				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=7 ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
						echo "$row[2],$row[3],$row[4],$row[5],";

				
				
				$db =mysqli_query($conn,"select * from marks where rollno ='$no' AND sem='$s' AND s=8  ;") or die ( " <br> MARKS TABLE is not available ");
				$row=mysqli_fetch_array($db);
				
						echo "$row[2],$row[3],$row[4],$row[5],";

			
	
	}
	else
	{
		echo "-1";
	}
				
			
			
		
?>
                  
                  
                  
