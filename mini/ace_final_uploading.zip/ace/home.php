<?php
	session_start();	
?>


<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>ACE Student Profile</title>
   
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
   
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
   
    <link href="assets/css/style.css" rel="stylesheet" />
   
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    
</head>
<body>





   
     <header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Curious Bird</a>
            </div>
           
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav navbar-right">
                	<li><a href="#">Profile</a></li>
                
                    
                    <li><a href="result.php">Results</a>
                    </li>
                    <li><a href="achievements.php">Achievements</a>
                    </li>
                    <li><a href="complaints.php">Complaints</a>
                    </li>
                    <li><a href="logout.php">Log-out</a>
                    </li>
                    
                   
                </ul>
            </div>
          
        </div>

    </nav>
          </header>

    <div id="home">
    <div class="container" >
        

               
                <script type='text/javascript'>
				location.hash='#no-';
				if(location.hash == '#no-')
				{
					location.hash='#_';
					window.onhashchange=function()
					{
						if(location.hash == '#no-')
							location.hash='#_';
					}
				}
			</script>
                   
                   
                   
                  <div class="col-md-33 col-ss-3">
                   
                   </br></br></br><font color="#ffffff" size="20px" ><center>Student Bio-Data</center></font>
                   
                   <div class="div-transs text-center"> 
                   
                   
                   
 
 <?php

	$name = $_SESSION['uname'];
	$no = $_SESSION['rno'];
	
	$dbhost = 'localhost';

	$dbuser = 'root';

	$dbpass = 'root';

	$dbname = 'ace';
	
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname) or die ("Could not connect: ");

	$db =mysqli_query($conn,"select * from profile where rollno ='$no' ;") or die ( " <br> database useage not availabe ");
	
	$row=mysqli_fetch_array($db);	

	$set=0;


	echo "
			
			
			</br></br><font color='#FFFFFF' size='4' background-color='#000000'  >
			<table border='1' width='90%' colspan='5' align='center' width='50%' > ";

	do
	{
		
		echo "		
		<tr><th><center> Student Roll No</center></th>      <td width='70%' ><center>$row[0]</center></td></tr>
		<tr><th><center> Student Name  </center></th>      <td width='70%' ><center>$row[1]</center></td></tr>
		<tr><th><center> Student Contact no  </center></th>      <td width='70%' ><center>$row[2]</center></td></tr>
		<tr><th><center> Father Name  </center></th>      <td width='70%' ><center>$row[3]</center></td></tr>
		<tr><th><center> Father Contact no  </center></th>      <td width='70%' ><center>$row[4]</center></td></tr>
		<tr><th><center> Student Date Of Birth  </center></th>      <td width='70%' ><center>$row[5]</center></td></tr>
		<tr><th><center> Batch  </center></th>      <td width='70%' ><center>$row[6]</center></td></tr>
		<tr><th><center> Branch  </center></th>      <td width='70%' ><center>$row[7]</center></td></tr>
		";
		
		$set=$row[10];	
		
		
		
		
		$db =mysqli_query($conn,"select sum(backlog) from aggregate where rollno='$no' ;") or die ( " <br> backlogs problem");
		$row=mysqli_fetch_array($db);
		
		
		echo "<tr><th><center> Backlogs  </center></th>      <td width='70%' ><center>$row[0]</center></td></tr>";
		
		$db =mysqli_query($conn,"select (sum(total)/sum(off))*100 from aggregate where rollno='$no' ;") or die ( " <br> database useage not availabe ");
		$row=mysqli_fetch_array($db);
		
		
		echo"<tr><th><center> Current Aggregate  </center></th>      <td width='70%' ><center>$row[0]</center></td></tr>
		</table>";
		
		
	}while($row=mysqli_fetch_array($db));
			
	
	if($set==0)
	{
		echo" <script> alert('  Please Kindly Change your password now to make your account more secure'); </script>";
					
		mysqli_query($conn,"update profile set pc=1 where rollno='$no' ;");
	
		echo "<script>window.open('pass.php',height='300',width='350' ,titlebar='no',toolbar='no',status='no',menubar='no',scrollbars='no',resizable='no')</script>";
	
	}
	
	



?>
 
 <br><br><center> <font color='#ffffff' >Change your password ? <input type='button' value='yes' onClick="window.open('pass.php',height='300',width='350' ,titlebar='no',toolbar='no',status='no',menubar='no',scrollbars='no',resizable='no')" /></font><br><br>
 
 </div>
 

 
 </div>
 </div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                   
                   
             
                   
                   
                   
                 <!-- DATA TILL HERE -->  
                
         
      
          </div>
    <!--End Header section  -->
    <!--Services Section-->
    
    

    <!-- Contact Section -->
    <section  id="contact-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                
                    <div id="social-icon">
                          <strong>  Address : </strong>ACE engineering college , Ankushapur , Ghatkesar , 501301 , Hyderabad .
                        <a href="#"><i class="fa fa-facebook fa-2x"></i></a>
                        <a href="#"><i class="fa fa-twitter fa-2x"></i></a>
                        <a href="#"><i class="fa fa-linkedin fa-2x"></i></a>
                        <a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
                        <a href="#"><i class="fa fa-pinterest fa-2x"></i></a>
                    </div>
                </div>
                

            </div>
        </div>
    </section>

    <!--End Contact Section -->
    <!--footer Section -->
    <div class="for-full-back " id="footer">
        2017 www.aceec.ac.in | All Right Reserved
         
    </div>
    <!--End footer Section -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.js"></script>
    <!-- PARALLAX SCRIPT   -->
    <script src="assets/plugins/4jquery.parallax-1.1.3.js"></script>
    <!-- CUSTOM SCRIPT   -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
